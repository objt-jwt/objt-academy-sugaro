SELECT 
	employee.NAME AS employee_NAME,
	employee.FIRSTNAME AS employee_FIRSTNAME,
	employee.DESCRIPTION AS employee_DESCRIPTION,
	((directTask.DTSSTOP - directTask.DTSSTART) * 3600 * 24 ) AS directTask_DURATION,
	AVG(directTask.ALLOCATION) AS directTask_ALLOCATION,
	activity.NAME AS ACT_NAME,
	activity.DESCRIPTION AS ACT_DESCR,
	resources.NAME AS RESOURCE_NAME,
	resources.DESCRIPTION AS RESOURCE_DESCR,
	resources.TYPE				 AS RESOURCE_TYPE,
	SUM(directTask.QTYDIRECTREWORK)	 AS DIRECT_REWORK,
	SUM(directTask.QTYINDIRECTREWORK) AS INDIRECT_REWORK,
	SUM(directTask.QTYREWORKED)		 AS QTYREWORKED,
	SUM(directTask.QTYREJECT)		 AS QTY_REJECT,
	SUM(directTask.QTY)				 AS QTY_YIELD	


FROM DCEREPORT_PRODUCTIONOPERATIONS productionoperation
     INNER JOIN dcereport_direct_tasks directTask ON productionoperation.OID = directTask.PRODUCTIONOPERATION_OID
     INNER JOIN dcereport_employees employee ON directTask.EMPLOYEE_OID = employee.OID
     LEFT OUTER JOIN dcereport_activities activity ON directTask.ACTIVITY_OID = activity.OID
     INNER JOIN dcereport_processresources resources  ON directTask.PROCESSRESOURCE_OID = resources.OID
WHERE productionoperation.OID = $P{PROD_OPERATION_OID}
AND resources.OID IS NOT NULL
GROUP BY
	employee.NAME,
	employee.FIRSTNAME,
	directTask.DTSSTART,
	directTask.DTSSTOP,
	employee.DESCRIPTION,
	activity.NAME,
	activity.DESCRIPTION,
	resources.NAME,
	resources.DESCRIPTION,
	resources.TYPE	
	
ORDER BY employee.NAME