SELECT SUM(DATEDIFF(SECOND, 
					(CASE WHEN ($X{LESS, interruptoperation.DTSSTART, FROM_DATE_TS}) THEN $P{FROM_DATE_TS} ELSE interruptoperation.DTSSTART END),
					(CASE WHEN (interruptoperation.DTSSTOP IS NULL) 
						  THEN (CASE WHEN ($X{LESS, GETDATE(), TO_DATE_TS}) THEN GETDATE() ELSE $P{TO_DATE_TS} END)
						  ELSE (CASE WHEN ($X{LESS, interruptoperation.DTSSTOP, TO_DATE_TS}) THEN interruptoperation.DTSSTOP ELSE $P{TO_DATE_TS} END)
					END)
		)) AS TOTAL_DURATION,
COUNT(interruptoperation.OID) AS TOTAL_COUNT
FROM DCEREPORT_INTERRUPTOPERATIONS interruptoperation, DCEREPORT_MACHINES machine
WHERE machine.NAME = $P{MACHINE_NAME}
AND interruptoperation.PROCESSRESOURCE_OID = machine.OID
AND $X{LESS, interruptoperation.DTSSTART, TO_DATE_TS}
AND (interruptoperation.DTSSTOP IS NULL OR $X{GREATER, interruptoperation.DTSSTOP, FROM_DATE_TS})
GROUP BY interruptoperation.PROCESSRESOURCE_OID