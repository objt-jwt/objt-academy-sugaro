SELECT TOP 1 machineoperation.OID
FROM dcereport_machineoperations machineoperation
WHERE OID = $P{machop_OID}