SELECT CASE segment.NAME
          WHEN 'OperationSetupSegment' THEN 'a Setup'
          WHEN 'OperationLoadSegment' THEN 'b Load'
          WHEN 'OperationRunSegment' THEN 'c Production'
          WHEN 'OperationUnloadSegment' THEN 'd Unload'
          WHEN 'OperationResetSegment' THEN 'e Reset'
          ELSE 'Unknown'
         END AS SEGMENT_NAME,
         SUM((SEGMENT.DTSSTOP - SEGMENT.DTSSTART)*3600*24) AS SEGMENT_DURATION
FROM DCEREPORT_MACHINEOP_SEGMENTS SEGMENT
WHERE SEGMENT.MACHINEOPERATION_OID = $P{MACHINE_OPERATION_OID}
GROUP BY SEGMENT.NAME
ORDER BY SEGMENT_NAME