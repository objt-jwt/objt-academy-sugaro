SELECT TOP 1
	productionoperation.NAME AS OPERATION_NAME,
	productionoperation.DESCRIPTION AS OPERATION_DESCR,
	processresource.NAME AS procres_NAME,
	processresource.OID AS procres_OID,
	processresource.DESCRIPTION AS procres_DESCRIPTION,
	item.NAME AS item_NAME,
	item.DESCRIPTION AS item_DESCRIPTION,
	machineoperation.DTSPLANNEDSTART AS RUN_DTSPLANNEDSTART,
	machineoperation.DTSPLANNEDSTOP AS RUN_DTSPLANNEDSTOP,
	DATEDIFF(SECOND, machineoperation.DTSPLANNEDSTART, machineoperation.DTSPLANNEDSTOP) AS RUN_PLANNED_DURATION,
	machineoperation.DTSSCHEDULEDSTART AS RUN_DTSSCHEDULEDSTART,
	machineoperation.DTSSTART AS RUN_DTSSTART,
	machineoperation.DTSSTOP AS RUN_DTSSTOP,
	DATEDIFF(SECOND, machineoperation.DTSSTART, machineoperation.DTSSTOP) AS RUN_DURATION,
	machineoperation.PRODUCTIONOPERATION_OID AS PRODUCTIONOPERATION_OID,
	machineoperation.OID AS RUN_OID,
	machineoperation.INSTRUCTIONSTATUS as INSTRUCTIONSTATUS
	
FROM DCEREPORT_MACHINEOPERATIONS machineoperation
		 INNER JOIN DCEREPORT_PRODUCTIONOPERATIONS productionoperation ON machineoperation.PRODUCTIONOPERATION_OID = productionoperation.OID
		 INNER JOIN DCEREPORT_PROCESSRESOURCES processresource ON machineoperation.PROCESSRESOURCE_OID = processresource.OID
		 INNER JOIN DCEREPORT_OEEOPERATIONREPORTS oeereport ON machineoperation.OID = oeereport.MACHINEOPERATION_OID
		 INNER JOIN DCEREPORT_ITEMS item ON productionoperation.ITEM_OID = item.OID
WHERE machineoperation.OID = $P{RUN_OID}
