SELECT			machineoperation.OID AS machop_OID,
				machineoperation.QTY AS item_QTY,
				machineoperation.QTYPLANNED AS item_PLANNED,
				machineoperation.QTYREJECT AS item_REJECT,
				machineoperation.QTYREJECTED AS item_REJECTED,
				machineoperation.QTYREWORKED AS item_REWORKED,
				machineoperation.QTYNRFT AS item_NRFT,
				machineoperation.UOM AS item_UOM,
                processresource.NAME AS resource_NAME,
                processresource.DESCRIPTION AS resource_DESCRIPTION,
				DATEDIFF(SECOND, machineoperation.DTSPLANNEDSTART, machineoperation.DTSPLANNEDSTOP) AS PLANNED_DURATION,
				DATEDIFF(SECOND, machineoperation.DTSSTART, machineoperation.DTSSTOP) AS DURATION,
				oeereport.SHIFT_NAME AS SHIFT_NAME,
				oeereport.SHIFT_DESCRIPTION AS SHIFT_DESCR
FROM   DCEREPORT_MACHINEOPERATIONS machineoperation
       INNER JOIN DCEREPORT_PRODUCTIONOPERATIONS productionoperation ON machineoperation.PRODUCTIONOPERATION_OID = productionoperation.OID
       INNER JOIN DCEREPORT_PROCESSRESOURCES processresource ON machineoperation.PROCESSRESOURCE_OID = processresource.OID
       INNER JOIN DCEREPORT_OEEOPERATIONREPORTS oeereport ON machineoperation.OID = oeereport.MACHINEOPERATION_OID
WHERE machineoperation.PRODUCTIONOPERATION_OID = $P{PROD_OPERATION_OID}
ORDER BY oeereport.DTSSTART