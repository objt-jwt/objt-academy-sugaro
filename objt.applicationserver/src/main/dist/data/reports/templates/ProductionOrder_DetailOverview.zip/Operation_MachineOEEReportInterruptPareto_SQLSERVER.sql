SELECT interruptreason.NAME AS INTERRUPTREASON_NAME,
       interruptreason.DESCRIPTION AS INTERRUPTREASON_DESCRIPTION,
       SUM(DATEDIFF(SECOND, 
	        (CASE WHEN ($X{LESS, interruptoperation.DTSSTART, FROM_DATE_TS}) THEN $P{FROM_DATE_TS} ELSE interruptoperation.DTSSTART END),
            (CASE WHEN (interruptoperation.DTSSTOP IS NULL) 
			      THEN (CASE WHEN ($X{LESS, GETDATE(), TO_DATE_TS}) THEN GETDATE() ELSE $P{TO_DATE_TS} END)
				  ELSE (CASE WHEN ($X{LESS, interruptoperation.DTSSTOP, TO_DATE_TS}) THEN interruptoperation.DTSSTOP ELSE $P{TO_DATE_TS} END) 
				  END)
	   )) AS INTERRUPTOPERATION_DURATION,
       COUNT(interruptoperation.OID) AS INTERRUPTOPERATION_COUNT
	   
FROM DCEREPORT_PRODUCTIONOPERATIONS productionoperation
INNER JOIN DCEREPORT_MACHINEOPERATIONS machineoperation ON productionoperation.OID = machineoperation.PRODUCTIONOPERATION_OID
LEFT OUTER JOIN DCEREPORT_INTERRUPTOPERATIONS interruptoperation ON interruptoperation.MACHINEOPERATION_OID = machineoperation.OID
LEFT OUTER JOIN DCEREPORT_INTERRUPTREASONS interruptreason ON interruptoperation.REASON_OID = interruptreason.OID

WHERE $X{LESS, interruptoperation.DTSSTART, TO_DATE_TS}
AND (interruptoperation.DTSSTOP IS NULL OR $X{GREATER, interruptoperation.DTSSTOP, FROM_DATE_TS})
AND productionoperation.OID = $P{PROD_OPERATION_OID}
GROUP BY interruptreason.NAME, interruptreason.DESCRIPTION
ORDER BY INTERRUPTOPERATION_DURATION DESC