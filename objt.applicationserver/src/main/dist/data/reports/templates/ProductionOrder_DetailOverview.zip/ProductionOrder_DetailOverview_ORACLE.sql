SELECT productionorder.OID AS ORDER_OID,
       productionorder.ID AS ORDER_ID,
       productionorder.DESCRIPTION AS ORDER_DESCRIPTION,
       productionorder.QTYPLANNED AS ORDER_QTYPLANNED,
       productionorder.QTYYIELD AS ORDER_QTYYIELD,
       productionorder.UOM AS ORDER_UOM,
       productionorder.RECIPE_NAME AS ORDER_RECIPE_NAME,
       productionorder.RECIPE_VARIANT AS ORDER_RECIPE_VARIANT,
       productionorder.RECIPE_VERSION AS ORDER_RECIPE_VERSION,
       productionorder.DTSPLANNEDSTART AS ORDER_DTSPLANNEDSTART,
       productionorder.DTSPLANNEDSTOP AS ORDER_DTSPLANNEDSTOP,
	     (productionorder.DTSPLANNEDSTOP - productionorder.DTSPLANNEDSTART) * 3600 * 24  AS PLANNED_DURATION,
       productionorder.DTSSCHEDULEDSTART AS ORDER_DTSSCHEDULEDSTART,
       productionorder.DTSSTART AS ORDER_DTSSTART,
       productionorder.DTSSTOP AS ORDER_DTSSTOP,
	     (productionorder.DTSSTOP - productionorder.DTSSTART) * 3600 * 24  AS DURATION,
       customer.NAME AS customer_NAME,
       customer.DESCRIPTION AS customer_DESCR
FROM DCEREPORT_PRODUCTIONORDERS productionorder
     LEFT JOIN DCEREPORT_CUSTOMERS customer ON customer.OID = productionorder.CUSTOMER_OID
WHERE productionorder.ID = $P{ORDER_ID}