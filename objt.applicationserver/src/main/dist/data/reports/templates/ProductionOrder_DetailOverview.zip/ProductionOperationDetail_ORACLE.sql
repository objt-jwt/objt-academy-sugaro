SELECT productionoperation.NAME AS prodop_NAME,
       productionoperation.DESCRIPTION AS prodop_DESCRIPTION,
       processresource.NAME AS procres_NAME,
			 processresource.OID AS procres_OID,
       processresource.DESCRIPTION AS procres_DESCRIPTION,
       item.NAME AS item_NAME,
       item.DESCRIPTION AS item_DESCRIPTION,
       productionoperation.DTSPLANNEDSTART AS machop_DTSPLANNEDSTART,
       productionoperation.DTSPLANNEDSTOP AS machop_DTSPLANNEDSTOP,
			 (productionoperation.DTSPLANNEDSTOP - productionoperation.DTSPLANNEDSTART) * 3600 * 24  AS PLANNED_DURATION,
       productionoperation.DTSSCHEDULEDSTART AS machop_DTSSCHEDULEDSTART,
       productionoperation.DTSSTART AS machop_DTSSTART,
			 productionoperation.DTSSTOP AS machop_DTSSTOP,
			 (productionoperation.DTSSTOP - productionoperation.DTSSTART) * 3600 * 24  AS DURATION,
       productionoperation.OID AS machop_OID
FROM DCEREPORT_PRODUCTIONOPERATIONS productionoperation
     LEFT JOIN DCEREPORT_PROCESSRESOURCES processresource ON productionoperation.PROCESSRESOURCE_OID = processresource.OID
     LEFT JOIN DCEREPORT_ITEMS item ON productionoperation.ITEM_OID = item.OID
WHERE productionoperation.OID = $P{PROD_OPERATION_OID}