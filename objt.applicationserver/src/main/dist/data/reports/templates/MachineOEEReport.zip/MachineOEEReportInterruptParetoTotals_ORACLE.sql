SELECT SUM((CASE WHEN ($X{LESS, interruptoperation.DTSSTART, FROM_DATE_TS}) THEN $P{FROM_DATE_TS} ELSE interruptoperation.DTSSTART END) -
		       (CASE WHEN (interruptoperation.DTSSTOP IS NULL) THEN (CASE WHEN ($X{LESS, SYSDATE, TO_DATE_TS}) THEN SYSDATE ELSE $P{TO_DATE_TS} END)
		             ELSE (CASE WHEN ($X{LESS, interruptoperation.DTSSTOP, TO_DATE_TS}) THEN interruptoperation.DTSSTOP ELSE $P{TO_DATE_TS} END) END))*24*60*-60  AS TOTAL_DURATION,
       COUNT(*) AS TOTAL_COUNT
FROM DCEREPORT_MACHINES machine, DCEREPORT_INTERRUPTOPERATIONS interruptoperation
WHERE machine.NAME = $P{MACHINE_NAME}
AND machine.OID = interruptoperation.PROCESSRESOURCE_OID
AND $X{LESS, interruptoperation.DTSSTART, TO_DATE_TS}
AND (interruptoperation.DTSSTOP IS NULL OR $X{GREATER, interruptoperation.DTSSTOP, FROM_DATE_TS})
GROUP BY interruptoperation.PROCESSRESOURCE_OID