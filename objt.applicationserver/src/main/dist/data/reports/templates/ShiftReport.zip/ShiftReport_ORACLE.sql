SELECT  
	machine.DESCRIPTION AS MACHINE_DESCRIPTION,
	machine.NAME AS MACHINE_NAME,
	SUM(operation_report.QTYPRODUCED) AS QTY,
	SUM(operation_report.QTYREJECT) AS REJECT,
	SUM(operation_report.QTYREWORKED) AS REWORKED,
	SUM(operation_report.QTYPRODUCED - operation_report.QTYREJECTED + operation_report.QTYREWORKED) as GOOD,
	AVG(operation_report.QTYPRODUCED) AS AVG_QTY,
	AVG(operation_report.QTYREJECT) AS AVG_REJECT,
	AVG(operation_report.QTYREWORKED) AS AVG_REWORKED,
	AVG(operation_report.QTYPRODUCED - operation_report.QTYREJECTED + operation_report.QTYREWORKED) as AVG_GOOD

FROM DCEREPORT_OEEREPORTS operation_report, DCEREPORT_MACHINES machine
WHERE $X{[GREATER, operation_report.SHIFT_START, FROM_DATE_TS}
AND $X{LESS], operation_report.SHIFT_START, TO_DATE_TS}
AND machine.NAME = $P{MACHINE_NAME}
AND operation_report.PROCESSRESOURCE_OID = machine.OID
AND rownum = 1
GROUP BY machine.DESCRIPTION, machine.NAME